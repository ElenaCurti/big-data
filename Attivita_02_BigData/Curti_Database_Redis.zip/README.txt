					DATABASE REDIS
-------------------------------------------------------------------------------

Il documento PDF contiene la relazione sul database NoSQL key-value Redis. 
Ho creato un'applicazione d'esempio, il cui funzionamento e gli screenshot
sono mostrati nel PDF. E' anche possibile avviare l'applicazione eseguendo 
il file redis_app.sh contenuto nella cartella "applicazione". 

Requisiti per usare l'applicazione: 
	- Python 3.9
	- Pacchetto redis di Python  	https://pypi.org/project/redis/
	- Redis				https://redis.io/docs/getting-started/
	- Redis Stack			https://redis.io/docs/stack/get-started/

-------------------------------------------------------------------------------
				Progetto realizzato da Elena Curti
-------------------------------------------------------------------------------